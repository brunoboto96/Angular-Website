export const projects = [
    {
        name: 'Cleaning Local Ponds',
        alias: 'PondCleanerz',
        description: 'Helping to clean local ponds.',
        status: 'In Progress',//0 = TODO, 1 = In Progress, 2 = Completed, 3 = Needs Revising
        img: './assets/img/project-list/pondcleanerz.gif'
    },
    {
        name: 'Cleaning Local Ponds2',
        alias: 'PondCleanerz',
        description: 'Helping to clean local ponds.',
        status: 'In Progress',
        img: './assets/img/project-list/pondcleanerz.gif'
    },
    {
        name: 'Cleaning Local Ponds3',
        alias: 'PondCleanerz',
        description: 'Helping to clean local ponds.',
        status: 'In Progress',
        img: './assets/img/project-list/pondcleanerz.gif'
    },
    {
        name: 'Cleaning Local Ponds4',
        alias: 'PondCleanerz',
        description: 'Helping to clean local ponds.',
        status: 'In Progress',
        img: './assets/img/project-list/pondcleanerz.gif'
    }
  ];